# LCAP Homepage

LCAP Homepage is the entrance of a LCAP Project, providing the capabilities to invoke other SAP Modules.

## Usage

Run command `LCAP Cockpit: Open Cockpit` to open the Homepage Panel.