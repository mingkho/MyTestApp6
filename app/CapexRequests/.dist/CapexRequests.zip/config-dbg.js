var appSettings = {
    "DefaultAppLanguage": "en",
    "ApplicationDisplayName": "Capex Requests"
}