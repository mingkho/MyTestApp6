var appSettings = {
    "DefaultAppLanguage": "en",
    "ApplicationDisplayName": "CapexApprovalUI"
}